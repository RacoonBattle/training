/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-gb/generic",{"dateFormatItem-yyyyMMMEd":"E, d MMM y G","field-dayperiod":"am/pm","dateFormatItem-MMMEd":"E d MMM","dateTimeFormat-full":"{1} {0}","dateFormatItem-hms":"h:mm:ss a","dateFormatItem-MMM":"LLL","dateTimeFormat-short":"{1} {0}","dateFormatItem-Gy":"y G","dateTimeFormat-medium":"{1} {0}","dateFormatItem-y":"y G","dateFormatItem-yyyy":"y G","dateFormatItem-Ed":"E d","dateFormatItem-GyMMMd":"d MMM y G","dateFormatItem-yyyyMMMM":"MMMM y G","dateFormat-long":"d MMMM y G","dateFormatItem-Hm":"HH:mm","dateFormat-medium":"d MMM y G","dateFormatItem-Hms":"HH:mm:ss","dateFormatItem-ms":"mm:ss","dateFormatItem-yyyyQQQQ":"QQQQ y G","dateTimeFormat-long":"{1} {0}","dateFormatItem-yyyyMd":"dd/MM/y GGGGG","dateFormatItem-yyyyMMMd":"d MMM y G","dateFormatItem-yyyyMEd":"E, dd/MM/y GGGGG","dateFormatItem-MMMd":"d MMM","dateFormatItem-H":"HH","dateFormatItem-MMMMd":"d MMMM","dateFormatItem-M":"LL","dateFormatItem-GyMMMEd":"E, d MMM y G","dateFormatItem-GyMMM":"MMM y G","dateFormatItem-MEd":"E dd/MM","dateFormatItem-yyyyQQQ":"QQQ y G","dateFormatItem-hm":"h:mm a","dateFormat-short":"dd/MM/y GGGGG","dateFormatItem-yyyyM":"MM/y GGGGG","dateFormat-full":"EEEE, d MMMM y G","dateFormatItem-Md":"dd/MM","dateFormatItem-yyyyMMM":"MMM y G","dateFormatItem-d":"d","dateFormatItem-h":"h a"});
