/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ro/coptic",{"field-second":"secundă","field-year-relative+-1":"Anul trecut","field-week":"săptămână","field-month-relative+-1":"Luna trecută","field-day-relative+-1":"ieri","field-day-relative+-2":"alaltăieri","field-year":"an","field-week-relative+0":"Săptămâna aceasta","field-week-relative+1":"Săptămâna viitoare","field-minute":"minut","field-week-relative+-1":"Săptămâna trecută","field-day-relative+0":"azi","field-hour":"oră","field-day-relative+1":"mâine","field-day-relative+2":"poimâine","field-day":"zi","field-month-relative+0":"Luna aceasta","field-month-relative+1":"Luna viitoare","field-dayperiod":"perioada zilei","field-month":"lună","field-era":"eră","field-year-relative+0":"Anul acesta","field-year-relative+1":"Anul viitor","field-weekday":"zi a săptămânii","field-zone":"zonă"});
