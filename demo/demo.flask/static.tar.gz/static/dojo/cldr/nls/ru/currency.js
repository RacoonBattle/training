/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ru/currency",{"HKD_displayName":"Гонконгский доллар","CHF_displayName":"Швейцарский франк","JPY_symbol":"¥","CAD_displayName":"Канадский доллар","CNY_displayName":"Юань Ренминби","USD_symbol":"$","AUD_displayName":"Австралийский доллар","JPY_displayName":"Японская иена","USD_displayName":"Доллар США","GBP_displayName":"Английский фунт стерлингов","EUR_displayName":"Евро"});
