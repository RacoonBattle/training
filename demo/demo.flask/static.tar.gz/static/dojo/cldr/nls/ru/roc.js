/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ru/roc",{"field-second":"Секунда","field-year-relative+-1":"В прошлом году","field-week":"Неделя","field-month-relative+-1":"В прошлом месяце","field-day-relative+-1":"Вчера","field-day-relative+-2":"Позавчера","field-year":"Год","field-week-relative+0":"На этой неделе","field-week-relative+1":"На следующей неделе","field-minute":"Минута","field-week-relative+-1":"На прошлой неделе","field-day-relative+0":"Сегодня","field-hour":"Час","field-day-relative+1":"Завтра","field-day-relative+2":"Послезавтра","field-day":"День","field-month-relative+0":"В этом месяце","field-month-relative+1":"В следующем месяце","field-dayperiod":"ДП/ПП","field-month":"Месяц","field-era":"Эра","field-year-relative+0":"В этом году","field-year-relative+1":"В следующем году","eraAbbr":["Before R.O.C.","Minguo"],"field-weekday":"День недели","field-zone":"Часовой пояс"});
