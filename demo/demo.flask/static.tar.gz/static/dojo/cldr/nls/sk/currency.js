/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sk/currency",{"HKD_displayName":"Hongkongský dolár","CHF_displayName":"Švajčiarský frank","JPY_symbol":"JPY","CAD_displayName":"Kanadský dolár","HKD_symbol":"HKD","CNY_displayName":"Čínsky jüan","USD_symbol":"USD","AUD_displayName":"Austrálsky dolár","JPY_displayName":"Japonský jen","CAD_symbol":"CAD","USD_displayName":"Americký dolár","CNY_symbol":"CNY","GBP_displayName":"Britská libra","GBP_symbol":"GBP","AUD_symbol":"AUD","EUR_displayName":"Euro"});
